import React from 'react'

function Footer() {
  return (
    <div className='my-7 '>
        <h2 className='text-center text-gray-600'>Created by Anandita Sharma. Triptales AI: Travel Recommendations tailored to your preferences</h2>
    </div>
  )
}

export default Footer